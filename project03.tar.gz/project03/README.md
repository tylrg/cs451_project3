# cs451_project3
 Project 3 for CS 451 (Decoding Half)

## Usage
  Run

  `cargo run 1 input`

  1 = thread count

  input = an existing directory to read encoded ppm files

## Notes
  You must remove .DS_Store from any directory that is being read from, done by navigating to the directory and running the following:

  `rm .DS_Store`

  The current directory is project03